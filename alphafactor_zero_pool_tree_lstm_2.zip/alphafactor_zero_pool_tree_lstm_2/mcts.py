import copy
import numpy as np
import torch
import threading
import time
import random
from collections import OrderedDict
from numba import jit
from env.alpha_env import AlphaEnv
from networks.policy_ import evaluate_policy_network
from networks.value_ import evaluate_expression_value
import multiprocessing

def apply_dirichlet_noise(root, epsilon=0.25, alpha=0.03):
    """
    为根节点的子节点应用 Dirichlet 噪声，调整先验概率。

    参数:
    root: 当前节点，包含子节点和原始先验概率
    epsilon: 噪声比例，控制原始先验与噪声的结合比例
    alpha: Dirichlet 分布的参数，控制噪声的分布
    """
    # 获取子节点数量
    num_children = len(root.childrens)
    
    # 生成 Dirichlet 噪声
    noise = np.random.dirichlet([alpha] * num_children)
    
    # 遍历每个子节点，修改先验概率
    for idx, (action, child_node) in enumerate(root.childrens.items()):
        # 修改先验概率：结合原有先验与 Dirichlet 噪声
        original_P = child_node.p
        child_node.p = (1 - epsilon) * original_P + epsilon * noise[idx]
        


class Node:

    def __init__(self, state = AlphaEnv(), parent=None, proba=1, action = None):
        """
        p : 该节点的概率，由策略网络给出
        n : 该节点在模拟过程中被访问的次数
        w : 该节点的总行动价值，由价值网络给出
        q : 平均行动价值（w / n）
        """
        self.state = state  # 环境状态
        self.p = proba
        self.n = 0
        self.w = 0
        self.q = 0
        self.action = action  # 从父节点到此节点的动作
        self.childrens = {}  # 子节点，键为动作，值为节点
        self.parent = parent
    

    def update(self, v):
        """ 在一次模拟后更新节点的统计信息 """

        self.w = self.w + v
        self.q = self.w / self.n if self.n > 0 else 0

    def update2(self, v):
        self.w += v
        q_avg = self.w / self.n if self.n > 0 else 0
        
        a=0.1
        if self.childrens:
            q_max = max(child.q for child in self.childrens.values())
        else:
            q_max = q_avg  # 若无子节点，则q_max退化为q_avg

        self.q = a * q_avg + (1 - a) * q_max

    def is_leaf(self):
        """ 检查节点是否是叶子节点 """

        return len(self.childrens) == 0

    def expand(self, probas):

        # 创建对应的子节点
        for action_output in probas:
            action_category = action_output.get('category')
            action_detail = action_output.get('action')
            prior_prob = action_output.get('prob')

            # 仅为概率大于0的动作创建子节点
            if prior_prob > 0:
                action_tuple = (action_category, action_detail)

                if action_tuple in self.childrens:
                    continue  # 已经创建过的子节点跳过

                # 应用动作，生成新状态
                new_state = copy.deepcopy(self.state)
                new_state.apply_action(action_category, action_detail)

                # 创建子节点
                child_node = Node(
                    state=new_state,
                    parent=self,
                    action=action_tuple,
                    proba=prior_prob,
                )
                self.childrens[action_tuple] = child_node



class EvaluatorThread(threading.Thread):
    def __init__(self, mcts, value_net, policy_net, eval_queue, result_queue, condition_search, condition_eval, BATCH_SIZE_EVAL):
        """ 用于在树搜索过程中批量评估局面 """

        threading.Thread.__init__(self)
        self.mcts = mcts
        self.eval_queue = eval_queue
        self.result_queue = result_queue
        self.value_net = value_net
        self.policy_net = policy_net
        self.condition_search = condition_search
        self.condition_eval = condition_eval
        self.BATCH_SIZE_EVAL = BATCH_SIZE_EVAL


    def run(self):
        for sim in range(self.mcts.MCTS_SIM // self.mcts.MCTS_PARALLEL):

            ## 等待 eval_queue 被填充新的待评估局面
            self.condition_search.acquire()
            while len(self.eval_queue) < self.mcts.MCTS_PARALLEL:
                self.condition_search.wait()
            self.condition_search.release()

            self.condition_eval.acquire()
            while len(self.result_queue) < self.mcts.MCTS_PARALLEL:
                keys = list(self.eval_queue.keys())
                max_len = self.BATCH_SIZE_EVAL if len(keys) > self.BATCH_SIZE_EVAL else len(keys)

                expressions = list(self.eval_queue.values())[0:max_len]  # 获取待评估的表达式

                # 获取每个表达式的价值（v）和策略概率（probas）
                v = [evaluate_expression_value(expression, value_net=self.value_net) for expression in expressions]
                probas = [evaluate_policy_network(expression, policy_net=self.policy_net)
                          for expression in expressions]

                ## 用结果替换 eval_queue 中的状态，并通知所有线程结果已可用
                for idx, i in zip(keys, range(max_len)):
                    del self.eval_queue[idx]
                    self.result_queue[idx] = (probas[i], v[i])

                self.condition_eval.notifyAll()
            self.condition_eval.release()
    



class SearchThread(threading.Thread):

    def __init__(self, mcts, eval_queue, result_queue, thread_id, lock, condition_search, condition_eval, c_puct):
        """ 运行单次模拟 """

        threading.Thread.__init__(self)
        self.mcts = mcts
        self.eval_queue = eval_queue
        self.result_queue = result_queue
        self.lock = lock
        self.thread_id = thread_id
        self.condition_eval = condition_eval
        self.condition_search = condition_search
        self.c_puct = c_puct
    

    def run(self):
        ##2.这里需要改成我们的环境和状态
        current_node = self.mcts.root

        #current_node = current_node.select(path = [],c_puct = self.c_puct)
        c_puct = self.c_puct
        current_node = self.mcts.root
    
        # 当当前节点已扩展且不是终止状态时，继续搜索
        while  current_node.childrens and not current_node.state.is_terminal_state():
            # 如果当前节点没有子节点，则视为叶子节点，停止搜索
            best_score = -float('inf')
            best_child = None
            total_cout=0
            for child in current_node.childrens.values():
                total_cout = child.n + total_cout
                
            # 根据 PUCT 公式选择得分最高的子节点
            for child in current_node.childrens.values():
                score = child.q + c_puct * child.p * np.sqrt(total_cout) / (1 + child.n)
                if score > best_score:
                    best_score = score
                    best_child = child
        
            # 如果找到了最佳子节点，则更新当前节点和路径
            if best_child is not None:
                current_node = best_child
            else:
                break  # 若没有合适的子节点，则退出循环

            ## 虚拟损失（由于多线程）
            self.lock.acquire()
            current_node.n += 1
            self.lock.release()
        
        expression = current_node.state.state_description()
        if not current_node.state.is_terminal_state():

            ## 将当前叶子节点的状态与随机的旋转变换添加到评估队列
            self.condition_search.acquire()
            self.eval_queue[self.thread_id] = expression
            self.condition_search.notify()
            self.condition_search.release()

            ## 等待评估线程完成
            self.condition_eval.acquire()
            while self.thread_id not in self.result_queue.keys():
                self.condition_eval.wait()

            ## 为避免 GPU 内存泄漏，复制结果
            result = self.result_queue.pop(self.thread_id)
            probas = result[0]
            v = float(result[1])
            self.condition_eval.release()

            self.lock.acquire()    
            current_node.expand(probas)
            
            ## 在根节点添加噪声
            if not current_node.parent:
                apply_dirichlet_noise(current_node, epsilon=0.25, alpha=0.03)

            ## 反向传播模拟结果
            while current_node.parent:
                current_node.update(v)
                current_node = current_node.parent
            self.lock.release()
        else:

            ## 将当前叶子节点的状态与随机的旋转变换添加到评估队列
            self.condition_search.acquire()
            self.eval_queue[self.thread_id] = expression
            self.condition_search.notify()
            self.condition_search.release()

            ## 等待评估线程完成
            self.condition_eval.acquire()
            while self.thread_id not in self.result_queue.keys():
                self.condition_eval.wait()

            ## 为避免 GPU 内存泄漏，复制结果
            result = self.result_queue.pop(self.thread_id)
            v = float(result[1])
            self.condition_eval.release()
            
            self.lock.acquire()
            ## 反向传播模拟结果
            while current_node.parent:
                current_node.update(v)
                current_node = current_node.parent
            self.lock.release()




class MCTS:
    def __init__(self, policy_net, value_net, MCTS_SIM, MCTS_PARALLEL, BATCH_SIZE_EVAL, device=torch.device('cpu')):
        self.root = Node()
        self.policy_net = policy_net
        self.value_net = value_net
        self.MCTS_SIM = MCTS_SIM
        self.MCTS_PARALLEL = MCTS_PARALLEL
        self.BATCH_SIZE_EVAL = BATCH_SIZE_EVAL
        self.device = device  # 新增设备属性
    
    def calculate_action_probs_from_node2(self):
        """
        从给定的节点计算动作概率。
    
        参数：
        - node: 当前节点对象，包含子节点和访问计数
        - temperature: 温度参数，用于平滑策略
    
        返回：
        - action_probs: 计算后的动作概率字典
        """
        # 获取当前节点的子节点访问计数
        action_counts = {action: child.n for action, child in self.root.childrens.items()}

        if not action_counts:
            return {}

        # 计算动作概率 π(a) ∝ N(s, a)^(1/τ)
        action_probs = {action: count   for action, count in action_counts.items()}

        # 归一化动作概率
        total = sum(action_probs.values())
        if total > 0:
            action_probs = {action: prob / total for action, prob in action_probs.items()}
        else:
            # 如果总和为0，使用均匀分布
            num_actions = len(action_counts)
            action_probs = {action: 1.0 / num_actions for action in action_counts}

        return action_probs
    
    def calculate_action_probs_from_node(self, temperature=1):
        """
        从给定的节点计算动作概率。
    
        参数：
        - node: 当前节点对象，包含子节点和访问计数
        - temperature: 温度参数，用于平滑策略
    
        返回：
        - action_probs: 计算后的动作概率字典
        """
        # 获取当前节点的子节点访问计数
        action_counts = {action: child.n for action, child in self.root.childrens.items()}

        if not action_counts:
            return {}

        # 计算动作概率 π(a) ∝ N(s, a)^(1/τ)
        action_probs = {action: (count ** (1.0 / temperature)) for action, count in action_counts.items()}

        # 归一化动作概率
        total = sum(action_probs.values())
        if total > 0:
            action_probs = {action: prob / total for action, prob in action_probs.items()}
        else:
            # 如果总和为0，使用均匀分布
            num_actions = len(action_counts)
            action_probs = {action: 1.0 / num_actions for action in action_counts}

        return action_probs
    
    def advance(self, move):
        """ 手动推进树，用于 GTP """
    
        # 使用 move 作为键来访问子节点，而不是使用索引 idx
        if move in self.root.childrens:
            self.root = self.root.childrens[move]  # 更新根节点为对应的子节点
        else:
            raise KeyError(f"Move {move} not found in childrens")

    def search(self, competitive,c_puct,temperature):
        """
        通过游戏树搜索最佳行动，通过策略网络和价值网络更新节点统计信息
        """

        ## 锁定以确保线程同步
        condition_eval = threading.Condition()
        condition_search = threading.Condition()
        lock = threading.Lock()

        ## 为评估器创建单线程（目前）
        eval_queue = OrderedDict()
        result_queue = {}
        evaluator = EvaluatorThread(self, self.value_net, self.policy_net, eval_queue, result_queue, condition_search, condition_eval, BATCH_SIZE_EVAL = self.BATCH_SIZE_EVAL)
        evaluator.start()

        threads = []
        ## 每个线程执行精确的模拟次数
        for sim in range(self.MCTS_SIM // self.MCTS_PARALLEL):
            for thread_id in range(self.MCTS_PARALLEL):
                threads.append(SearchThread(self, eval_queue, result_queue, thread_id, 
                                        lock, condition_search, condition_eval,c_puct=c_puct))
                threads[-1].start()
            for thread in threads:
                thread.join()
        evaluator.join()

        ## 选择最佳行动
        if competitive:
            final_probas = self.calculate_action_probs_from_node2()
        else:
            final_probas = self.calculate_action_probs_from_node(temperature=temperature)

        # 将 action_probs 转换为列表
        actions = list(final_probas.keys())
        probabilities = list(final_probas.values())

        ## 根据是否为competitive决定动作选择方式
        if competitive:
            # 选择最有可能的动作（确定性选择）
            final_move = max(zip(actions, probabilities), key=lambda x: x[1])[0]
        else:
            final_move = None
            cumulative_probabilities = []
            cumulative_sum = 0
            for p in probabilities:
                cumulative_sum += p
                cumulative_probabilities.append(cumulative_sum)

            random_value = random.random()

            for i, cumulative_prob in enumerate(cumulative_probabilities):
                if random_value < cumulative_prob:
                    final_move = actions[i]
                    break
            
            # 如果循环结束后 final_move 仍没被赋值，就选择最后一个动作做兜底
            if final_move is None:
                final_move = actions[-1]

        self.advance(final_move)

        return final_probas, final_move
    
if __name__ == "__main__":
        import math
        import logging
        from mimetypes import init  # 首先导入 logging
        import torch
        import torch.nn as nn
        import torch.optim as optim
        from torch.utils.data import DataLoader
        import os
        import csv
        import copy
        import random
        from models.linear_alpha_pool import LinearAlphaPool, MseAlphaPool
        from train_preparation_pool import *  # 在配置日志之后再导入
        import numpy as np
        import random

        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        token_map = create_token_map()
        vocab_size = len(token_map) + 1
        embed_dim = 128
        nhead = 8
        nhid = 128
        nlayers = 2
        dropout = 0.1
        
        #seed = 3  # 可以选择任何喜欢的数字
        #set_seed(seed)

        # 初始化特征提取器
        feature_extractor = FeatureExtractor(
            vocab_size=vocab_size,
            embed_dim=embed_dim,
            nhead=nhead,
            nhid=nhid,
            nlayers=nlayers,
            dropout=dropout
        ).to(device)

        #feature_extractor.apply(initialize_weights)

        # 初始化策略网络和价值网络
        policy_net = PolicyNetwork(feature_extractor=feature_extractor, embed_dim=embed_dim).to(device)
        value_net = ValueNetwork(feature_extractor=feature_extractor, embed_dim=embed_dim).to(device)

        env = AlphaEnv()
        root = Node(state=copy.deepcopy(env))
        mcts = MCTS(policy_net, value_net, device)
        print(mcts.root.state.state_description())
        selected_action = mcts.search(competitive=False)
        print(mcts.root.state.state_description())
        selected_action = mcts.search(competitive=False)
        print(mcts.root.state.state_description())
        selected_action = mcts.search(competitive=False)
        print(mcts.root.state.state_description())
        selected_action = mcts.search(competitive=False)
        print(mcts.root.state.state_description())



#@jit(nopython=True)
#def _opt_select(nodes, c_puct=C_PUCT):
#    """ 基于 PUCT 公式优化的选择方法 """

#    total_count = 0
#    for i in range(nodes.shape[0]):
#        total_count += nodes[i][1]
    
#    action_scores = np.zeros(nodes.shape[0])
#    for i in range(nodes.shape[0]):
#        action_scores[i] = nodes[i][0] + c_puct * nodes[i][2] * \
#                (np.sqrt(total_count) / (1 + nodes[i][1]))
    
#    equals = np.where(action_scores == np.max(action_scores))[0]
#    if equals.shape[0] > 0:
#        return np.random.choice(equals)
#    return equals[0]

        ## 遍历树直到叶子节点
    #    while not current_node.is_leaf() and not current_node.state.is_terminal_state():
    #        ## 选择最大化 PUCT 算法的行动
    #        print(current_node.childrens)  # 查看childrens的内容

    #       current_node = current_node.childrens[_opt_select( \
    #                np.array([[node.q, node.n, node.p] \
    #                for node in current_node.childrens]))]

            ## 虚拟损失（由于多线程）
    #        self.lock.acquire()
    #        current_node.n += 1
    #        self.lock.release()


    

