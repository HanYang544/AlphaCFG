def compute_expression_similarity(expr_str1, expr_str2, token_map=None):
    """
    计算两个表达式字符串之间的归一化相似度。
    
    参数:
        expr_str1: 第一个表达式字符串，例如 "Div Max $volume 40 Med $open 40"
        expr_str2: 第二个表达式字符串，例如 "Med $open 40"
        token_map: 可选参数，如果不传入，则内部创建一个 TokenMap 对象
    
    返回:
        一个浮点数，相似度归一化值，介于 0 到 1 之间。
    """
    # 如果没有传入 token_map，则创建一个新的 TokenMap 实例
    if token_map is None:
        token_map = TokenMap()
    
    # 解析表达式字符串为表达式树
    tree1 = parse_expression(expr_str1, token_map)
    tree2 = parse_expression(expr_str2, token_map)
    
    # 计算归一化相似度
    similarity = normalize_similarity(tree1, tree2)
    return similarity

# 以下是内部使用到的部分代码

import re

from data.expression import *
from env.features import *

class TokenMap:
    def __init__(self):
        self.token_map = {
            # ========== 1) Unary operators ==========
            'Log': 1,
            'Abs': 2,
            'Sign': 3,
            'CSRank': 4,

            # ========== 2) Binary operators ==========
            'Add': 5,
            'Sub1': 6,
            'Sub2': 7,
            'Mul': 8,
            'Div1': 9,
            'Div2': 10,
            'Pow1': 11,
            'Pow2': 12,
            'Greater': 13,
            'Less': 14,

            # ========== 3) Rolling operators ==========
            'Ref': 15,
            'Skew': 16,
            'Kurt': 17,
            'Mean': 18,
            'Sum': 19,
            'Std': 20,
            'Var': 21,
            'Max': 22,
            'Min': 23,
            'Med': 24,
            'Rank': 25,
            'Mad': 26,
            'Delta': 27,
            'WMA': 28,

            # ========== 4) Paired rolling operators ==========
            'Cov': 29,
            'Corr': 30,

            # ========== 5) Features ==========
            '$high': 31,
            '$low': 32,
            '$volume': 33,
            '$open': 34,
            '$close': 35,
            '$vwap': 36,

            # ========== 6) Special tokens ==========
            'E': 37,         # 非终结符 E
            'Q': 38,         # 新增非终结符 Q
            'num': 39,       # 用于占位数字（num_range）

            # ========== 7) Constants ==========
            '-0.1': 40,
            '-0.05': 41,
            '-0.01': 42,
            '0.01': 43,
            '0.05': 44,
            '0.1': 45,

            # ========== 8) Numbers (num_range) ==========
            '40': 46,
            '30': 47,
            '20': 48
        }
        self.operator_arities = {
            # Unary operators
            'Log': 1,
            'Abs': 1,
            'Sign': 1,
            'CSRank': 1,

            # Binary operators
            'Add': 2,
            'Sub1': 2,
            'Sub2': 2,
            'Mul': 2,
            'Div1': 2,
            'Div2': 2,
            'Pow1': 2,
            'Pow2': 2,
            'Greater': 2,
            'Less': 2,

            # Rolling operators
            'Ref': 2,
            'Skew': 2,
            'Kurt': 2,
            'Mean': 2,
            'Sum': 2,
            'Std': 2,
            'Var': 2,
            'Max': 2,
            'Min': 2,
            'Med': 2,
            'Mad': 2,
            'Rank': 2,
            'Delta': 2,
            'WMA': 2,
            'EMA': 2,

            # Paired rolling operators
            'Cov': 3,
            'Corr': 3
        }

    def get_word_id(self, token):
        return self.token_map.get(token, 36)  # 默认使用 'num' 的 ID

    def get_arity(self, operator):
        return self.operator_arities.get(operator, 0)  # 默认 arity 为 0

class ExpressionTree:
    def __init__(self, value=None, children=None, is_operator=False):
        """
        初始化表达式树节点
        :param value: 节点的值，例如 'Add', '$high', '0.05' 等
        :param children: 子节点列表
        :param is_operator: 是否为操作符节点
        """
        self.value = value
        self.children = children if children is not None else []
        self.is_operator = is_operator

    def is_leaf(self):
        """判断是否为叶子节点"""
        return len(self.children) == 0

    def __repr__(self):
        """返回节点的字符串表示"""
        if self.is_leaf():
            return f"Leaf({self.value})"
        else:
            children_repr = ", ".join([str(child) for child in self.children])
            return f"({self.value}({children_repr}))"

def parse_expression(expression_str, token_map):
    """
    解析没有括号的表达式字符串并构建语法树
    :param expression_str: 表达式字符串，例如 'Rank Corr $high 0.05 40 40'
    :param token_map: TokenMap 对象
    :return: ExpressionTree 对象
    """
    tokens = expression_str.strip().split()
    tokens = tokens[::-1]  # Reverse for efficient pop from the end

    def helper():
        if not tokens:
            return None
        token = tokens.pop()
        if token in token_map.operator_arities:
            arity = token_map.get_arity(token)
            children = []
            for _ in range(arity):
                child = helper()
                if child is not None:
                    children.append(child)
            return ExpressionTree(value=token, children=children, is_operator=True)
        else:
            # It's either a variable or a constant/number
            return ExpressionTree(value=token, is_operator=False)

    tree = helper()
    return tree

def common_subtree_size(t1, t2):
    """
    如果 t1 和 t2 同构，则返回它们的公共子树大小（节点数量），否则返回 0。
    这里假设同构要求节点的值相同、子节点数量相同且顺序一致。
    """
    if t1.value != t2.value or len(t1.children) != len(t2.children):
        return 0
    size = 1  # 当前节点匹配
    for child1, child2 in zip(t1.children, t2.children):
        child_size = common_subtree_size(child1, child2)
        if child_size == 0:
            return 0
        size += child_size
    return size

def get_all_subtrees(tree):
    """
    递归获取表达式树中的所有子树（包括自身）。
    """
    subtrees = [tree]
    for child in tree.children:
        subtrees.extend(get_all_subtrees(child))
    return subtrees

def max_common_subtree_size(tree1, tree2):
    """
    遍历两个树的所有子树，计算最大公共子树大小。
    """
    subtrees1 = get_all_subtrees(tree1)
    subtrees2 = get_all_subtrees(tree2)
    max_size = 0
    for t1 in subtrees1:
        for t2 in subtrees2:
            size = common_subtree_size(t1, t2)
            if size > max_size:
                max_size = size
    return max_size

def normalize_similarity(tree1, tree2):
    """
    将最大公共子树大小归一化，归一化方式为：
    similarity = max_common_subtree_size / max(total_nodes(tree1), total_nodes(tree2))
    """
    def total_nodes(tree):
        return 1 + sum(total_nodes(child) for child in tree.children)
    
    max_common = max_common_subtree_size(tree1, tree2)
    total1 = total_nodes(tree1)
    total2 = total_nodes(tree2)
    norm_sim = max_common / max(total1, total2)
    return norm_sim

def expression_to_prefix_str(expr: Expression) -> str:
    """
    将 Expression 类实例转换为前缀表达式字符串。
    例如，对于表达式 Div(Max($volume,40), Med($open,40))
    返回 "Div Max $volume 40 Med $open 40"
    """
    # 如果是常数，直接返回数字字符串
    if isinstance(expr, Constant):
        return str(expr._value)
    # 如果是特征（Feature），直接调用其 __str__ 方法（一般返回形如 "$xxx" 的字符串）
    elif isinstance(expr, Feature):
        return str(expr)
    # 如果是一元运算符
    elif isinstance(expr, UnaryOperator):
        return f"{type(expr).__name__} " + expression_to_prefix_str(expr._operand)
    # 如果是二元运算符
    elif isinstance(expr, BinaryOperator):
        return f"{type(expr).__name__} " + expression_to_prefix_str(expr._lhs) + " " + expression_to_prefix_str(expr._rhs)
    # 如果是滚动运算符（RollingOperator），假设第二个参数为窗口长度
    elif isinstance(expr, RollingOperator):
        return f"{type(expr).__name__} " + expression_to_prefix_str(expr._operand) + " " + str(expr._delta_time)
    # 如果是成对滚动运算符（PairRollingOperator）
    elif isinstance(expr, PairRollingOperator):
        return f"{type(expr).__name__} " + expression_to_prefix_str(expr._lhs) + " " + expression_to_prefix_str(expr._rhs) + " " + str(expr._delta_time)
    else:
        # 其他情况，直接使用 str(expr)
        return str(expr)
    
# 测试包装的函数
if __name__ == "__main__":
    expr1 = Mad(Sign(Mul(Constant(0.05),vwap)),20)
    expr2 = vwap
    #expr_str1 = "$open"
    #expr_str2 = "Med $open num"
    expr_str1 = expression_to_prefix_str(expr1)
    expr_str2 = expression_to_prefix_str(expr2)
    sim = compute_expression_similarity(expr_str1, expr_str2)
    print("Normalized similarity:", sim)
