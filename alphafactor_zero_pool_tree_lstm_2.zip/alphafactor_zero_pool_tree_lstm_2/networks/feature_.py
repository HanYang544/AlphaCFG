import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl
from dgl import DGLGraph

# 步骤 1: 定义词汇表和操作符参数数量
class TokenMap:
    def __init__(self):
        self.token_map = {
            # ========== 1) Unary operators ==========
            'Log': 1,
            'Abs': 2,
            'Sign': 3,
            'CSRank': 4,

            # ========== 2) Binary operators ==========
            'Add': 5,
            'Sub1': 6,
            'Sub2': 7,
            'Mul': 8,
            'Div1': 9,
            'Div2': 10,
            'Pow1': 11,
            'Pow2': 12,
            'Greater': 13,
            'Less': 14,

            # ========== 3) Rolling operators ==========
            'Ref': 15,
            'Skew': 16,
            'Kurt': 17,
            'Mean': 18,
            'Sum': 19,
            'Std': 20,
            'Var': 21,
            'Max': 22,
            'Min': 23,
            'Med': 24,
            'Rank': 25,
            'Mad': 26,
            'Delta': 27,
            'WMA': 28,

            # ========== 4) Paired rolling operators ==========
            'Cov': 29,
            'Corr': 30,

            # ========== 5) Features ==========
            '$high': 31,
            '$low': 32,
            '$volume': 33,
            '$open': 34,
            '$close': 35,
            '$vwap': 36,

            # ========== 6) Special tokens ==========
            'E': 37,         # 非终结符 E
            'Q': 38,         # 新增非终结符 Q
            'num': 39,       # 用于占位数字（num_range）

            # ========== 7) Constants ==========
            '-0.1': 40,
            '-0.05': 41,
            '-0.01': 42,
            '0.01': 43,
            '0.05': 44,
            '0.1': 45,

            # ========== 8) Numbers (num_range) ==========
            '40': 46,
            '30': 47,
            '20': 48
        }
        self.operator_arities = {
            # Unary operators
            'Log': 1,
            'Abs': 1,
            'Sign': 1,
            'CSRank': 1,

            # Binary operators
            'Add': 2,
            'Sub1': 2,
            'Sub2': 2,
            'Mul': 2,
            'Div1': 2,
            'Div2': 2,
            'Pow1': 2,
            'Pow2': 2,
            'Greater': 2,
            'Less': 2,

            # Rolling operators
            'Ref': 2,
            'Skew': 2,
            'Kurt': 2,
            'Mean': 2,
            'Sum': 2,
            'Std': 2,
            'Var': 2,
            'Max': 2,
            'Min': 2,
            'Med': 2,
            'Mad': 2,
            'Rank': 2,
            'Delta': 2,
            'WMA': 2,
            'EMA': 2,

            # Paired rolling operators
            'Cov': 3,
            'Corr': 3
        }

    def get_word_id(self, token):
        # 默认使用 'num' 的 ID (此处 39 为 num)
        return self.token_map.get(token, 39)

    def get_arity(self, operator):
        return self.operator_arities.get(operator, 0)  # 默认 arity 为 0


# 步骤 2: 定义表达式树节点
class ExpressionTree:
    def __init__(self, value=None, children=None, is_operator=False):
        """
        初始化表达式树节点
        :param value: 节点的值，例如 'Add', '$high', '0.05' 等
        :param children: 子节点列表
        :param is_operator: 是否为操作符节点
        """
        self.value = value
        self.children = children if children is not None else []
        self.is_operator = is_operator

    def is_leaf(self):
        """判断是否为叶子节点"""
        return len(self.children) == 0

    def __repr__(self):
        """返回节点的字符串表示"""
        if self.is_leaf():
            return f"Leaf({self.value})"
        else:
            children_repr = ", ".join([str(child) for child in self.children])
            return f"({self.value}({children_repr}))"


# 步骤 3: 实现表达式解析器
def parse_expression(expression_str, token_map):
    """
    解析没有括号的表达式字符串并构建语法树
    :param expression_str: 表达式字符串，例如 'Rank Corr $high 0.05 40 40'
    :param token_map: TokenMap 对象
    :return: ExpressionTree 对象
    """
    tokens = expression_str.strip().split()
    tokens = tokens[::-1]  # 反转列表以便从末尾高效 pop

    def helper():
        if not tokens:
            return None
        token = tokens.pop()
        if token in token_map.operator_arities:
            arity = token_map.get_arity(token)
            children = []
            for _ in range(arity):
                child = helper()
                if child is not None:
                    children.append(child)
            return ExpressionTree(value=token, children=children, is_operator=True)
        else:
            # 变量或常量/数字
            return ExpressionTree(value=token, is_operator=False)

    tree = helper()
    return tree


# 步骤 4: 将语法树转换为 DGL 图
def tree_to_dgl_graph(tree):
    """
    将表达式树转换为 DGL 图。
    :param tree: ExpressionTree 对象
    :return: DGL 图对象和节点列表
    """
    nodes = []
    edges_src = []
    edges_dst = []

    def traverse(node):
        """
        递归遍历树，构建节点和边。
        :param node: 当前节点
        :return: 当前节点的索引
        """
        idx = len(nodes)
        nodes.append(node)
        for child in node.children:
            child_idx = traverse(child)
            edges_src.append(child_idx)  # 子节点
            edges_dst.append(idx)        # 父节点
        return idx

    traverse(tree)
    # 使用最新的 DGL API 创建图
    src = torch.tensor(edges_src, dtype=torch.int64)
    dst = torch.tensor(edges_dst, dtype=torch.int64)
    g = dgl.graph((src, dst), num_nodes=len(nodes))
    return g, nodes


# 步骤 5: 定义 TreeLSTMCell
class TreeLSTMCell(nn.Module):
    def __init__(self, x_size, h_size, max_children=3):
        """
        初始化 TreeLSTM 单元
        :param x_size: 输入特征维度
        :param h_size: 隐藏状态维度
        :param max_children: 最大子节点数量（默认为3）
        """
        super(TreeLSTMCell, self).__init__()
        self.h_size = h_size
        self.max_children = max_children

        # 输入门、输出门和更新门的权重
        self.W_iou = nn.Linear(x_size, 3 * h_size, bias=True)
        self.U_iou = nn.Linear(max_children * h_size, 3 * h_size, bias=False)

        # 遗忘门的权重
        self.U_f = nn.Linear(max_children * h_size, max_children * h_size, bias=False)

        # 初始化参数
        self.reset_parameters()

    def reset_parameters(self):
        """初始化权重参数"""
        nn.init.xavier_uniform_(self.W_iou.weight)
        nn.init.xavier_uniform_(self.U_iou.weight)
        nn.init.xavier_uniform_(self.U_f.weight)
        self.W_iou.bias.data.fill_(0)

    def message_func(self, edges):
        """
        消息传递函数，传递子节点的隐藏状态和细胞状态
        :param edges: DGL edges
        :return: 包含子节点隐藏状态 'h' 和细胞状态 'c' 的字典
        """
        return {'h': edges.src['h'], 'c': edges.src['c']}

    def reduce_func(self, nodes):
        """
        聚合函数，接收来自子节点的信息，计算遗忘门并更新细胞状态
        :param nodes: DGL nodes
        :return: 包含 'iou_child' 和 'c' 的字典
        """
        # 拼接来自子节点的 h
        # nodes.mailbox['h'] shape: (batch_size, num_children, h_size)
        h_cat = nodes.mailbox['h'].reshape(nodes.mailbox['h'].size(0), -1)  # (batch_size, num_children * h_size)

        num_children = nodes.mailbox['h'].shape[1]
        # 如果当前节点的子节点数量小于 max_children，补齐0
        if num_children < self.max_children:
            padding_h = torch.zeros(nodes.mailbox['h'].size(0), (self.max_children - num_children) * self.h_size, device=h_cat.device)
            h_cat = torch.cat([h_cat, padding_h], dim=1)  # (batch_size, max_children * h_size)
            # Similarly pad 'c'
            padding_c = torch.zeros(nodes.mailbox['c'].size(0), (self.max_children - num_children), self.h_size, device=h_cat.device)
            c_padded = torch.cat([nodes.mailbox['c'], padding_c], dim=1)  # (batch_size, max_children, h_size)
        else:
            c_padded = nodes.mailbox['c']  # (batch_size, max_children, h_size)

        # 计算遗忘门
        f = torch.sigmoid(self.U_f(h_cat))  # (batch_size, max_children * h_size)

        # 重新reshape f to (batch_size, max_children, h_size)
        f = f.view(nodes.mailbox['h'].shape[0], self.max_children, self.h_size)  # (batch_size, max_children, h_size)

        # 计算新的细胞状态
        c = torch.sum(f * c_padded, dim=1)  # (batch_size, h_size)

        # 计算 iou_child
        iou_child = self.U_iou(h_cat)  # (batch_size, 3 * h_size)
        return {'iou_child': iou_child, 'c': c}

    def apply_node_func(self, nodes):
        """
        应用函数，计算输入门、输出门和更新门，并更新隐藏状态和细胞状态
        :param nodes: DGL nodes
        :return: 包含更新后的 'h' 和 'c' 的字典
        """
        # 如果节点数据中没有 'iou_child'，说明该节点为叶节点，设置默认值为0
        if 'iou_child' in nodes.data:
            iou_child = nodes.data['iou_child']
        else:
            # 这里根据 x 的形状构造一个零张量，形状为 (batch_size, 3 * h_size)
            x = nodes.data['x']
            iou_child = torch.zeros(x.size(0), 3 * self.h_size, device=x.device)

        # 获取节点的嵌入向量 x
        x = nodes.data['x']  # (batch_size, x_size)

        # 计算 W_iou(x)
        iou_node = self.W_iou(x)  # (batch_size, 3 * h_size)

        # 计算最终的 iou
        iou = iou_node + iou_child  # (batch_size, 3 * h_size)

        # 分割 i, o, u
        i, o, u = torch.chunk(iou, 3, dim=1)  # (batch_size, h_size) each

        # 计算门控
        i = torch.sigmoid(i)
        o = torch.sigmoid(o)
        u = torch.tanh(u)

        # 更新细胞状态和隐藏状态
        c = i * u + nodes.data['c']          # (batch_size, h_size)
        h = o * torch.tanh(c)                # (batch_size, h_size)

        return {'h': h, 'c': c}


# 步骤 6: 定义 TreeLSTM 模型
class TreeLSTMModel(nn.Module):
    def __init__(self, num_vocabs, x_size, h_size, dropout=0.5, pretrained_emb=None, max_children=3):
        """
        初始化 TreeLSTM 模型
        :param num_vocabs: 词汇表大小
        :param x_size: 输入嵌入维度
        :param h_size: 隐藏状态维度
        :param dropout: Dropout 概率
        :param pretrained_emb: 预训练嵌入（可选）
        :param max_children: 最大子节点数量
        """
        super(TreeLSTMModel, self).__init__()
        self.h_size = h_size
        self.embedding = nn.Embedding(num_vocabs, x_size)
        if pretrained_emb is not None:
            print('Using pretrained embeddings')
            self.embedding.weight.data.copy_(pretrained_emb)
            self.embedding.weight.requires_grad = True
        self.dropout = nn.Dropout(dropout)
        self.cell = TreeLSTMCell(x_size, h_size, max_children=max_children)

    def forward(self, graph, wordid, mask, h, c):
        """
        前向传播
        :param graph: DGL 图
        :param wordid: 节点的词汇ID
        :param mask: 节点的掩码（当前未使用）
        :param h: 初始隐藏状态
        :param c: 初始细胞状态
        :return: h_out（隐藏状态特征向量）
        """
        # 嵌入层
        embeds = self.embedding(wordid)  # (num_nodes, x_size)
        embeds = self.dropout(embeds)

        # 初始化节点的 h 和 c
        graph.ndata['h'] = h
        graph.ndata['c'] = c

        # 设置 'x' 为嵌入向量
        graph.ndata['x'] = embeds

        # 传播 TreeLSTM
        graph.update_all(message_func=self.cell.message_func,
                        reduce_func=self.cell.reduce_func,
                        apply_node_func=self.cell.apply_node_func)

        # 获取隐藏状态
        h_out = self.dropout(graph.ndata['h'])
        return h_out


# ========== 对齐后的 FeatureExtractor ==========
class FeatureExtractor(nn.Module):
    def __init__(self, embed_dim=256, h_size=256, dropout=0.5):
        super().__init__()
        self.token_map = TokenMap()
        self.model = TreeLSTMModel(
            num_vocabs=max(self.token_map.token_map.values()) + 1,
            x_size=embed_dim,
            h_size=h_size,
            dropout=dropout
        )
        self.fc = nn.Linear(h_size, h_size)

    def forward(self, expression: str) -> torch.Tensor:
        # 表达式 -> 树 -> DGL图
        tree = parse_expression(expression, self.token_map)
        graph, nodes = tree_to_dgl_graph(tree)
        graph = graph.to(next(self.parameters()).device)

        # 节点特征
        wordid = torch.tensor(
            [self.token_map.get_word_id(node.value) for node in nodes],
            dtype=torch.long
        ).to(graph.device)

        # 前向传播
        h = torch.zeros(graph.number_of_nodes(), self.model.h_size).to(graph.device)
        c = torch.zeros(graph.number_of_nodes(), self.model.h_size).to(graph.device)
        feature = self.model(graph, wordid, None, h, c)
        root_h = feature[-1].unsqueeze(0)  # [1, h_size]
        return self.fc(root_h)
















