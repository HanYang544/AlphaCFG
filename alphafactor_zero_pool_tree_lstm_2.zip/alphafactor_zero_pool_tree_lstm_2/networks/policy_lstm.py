# policy_.py
import torch
import torch.nn as nn
from env.token_v import create_token_map, parse_expression_to_tokens, get_first_token
from networks.feature_ import FeatureExtractor  # 确保这是 LSTM-based 的 FeatureExtractor

# 类别名称映射
CATEGORY_MAP = {
    0: 'Vari',
    1: 'constant',
    2: 'unaryop',
    3: 'binaryop',
    4: 'rollingop',
    5: 'pairedrollingop',
    # 注意：不再包括 'num' 类别，因为当第一个未扩展符号是 'num' 时，我们只需要预测 num 的值
}

# 动作映射
ACTION_MAP = {
    'unaryop': ['Log', 'Abs', 'Sign', 'CSRank'],  # 包含所有一元操作符

    'binaryop': ['Add', 'Sub1', 'Sub2','Mul', 'Div1', 'Div2', 'Greater', 'Less', 'Pow1','Pow2'],  # 包含所有二元操作符

    'rollingop': ['Ref', 'Skew', 'Kurt', 'Mean', 'Sum', 'Std', 'Var', 'Max', 'Min', 'Med', 'Rank', 'Mad', 'Delta', 'WMA'],  # 包含所有滚动操作符

    'pairedrollingop': ['Cov', 'Corr'],  # 包含所有配对滚动操作符

    'Vari': ['high', 'low', 'volume', 'open', 'close', 'vwap'],  # 包含所有市场特征

    'constant': [-0.1, -0.05, -0.01, 0.01, 0.05, 0.1],  # 包含所有常量

    'num': [20, 30, 40]  # 包含固定的数字范围
}

class PolicyNetwork(nn.Module):
    def __init__(self, feature_extractor, embed_dim):
        super(PolicyNetwork, self).__init__()
        self.feature_extractor = feature_extractor

        # 添加两个 64 维的隐藏层
        self.hidden_layer1 = nn.Linear(embed_dim, 64)
        self.hidden_layer2 = nn.Linear(64, embed_dim)

        # 各个类别的输出维度
        self.category_head = nn.Linear(embed_dim, len(CATEGORY_MAP))
        # 各类别的具体动作映射，使用 nn.ModuleDict
        self.action_heads = nn.ModuleDict({
            'unaryop': nn.Linear(embed_dim, len(ACTION_MAP['unaryop'])),
            'binaryop': nn.Linear(embed_dim, len(ACTION_MAP['binaryop'])),
            'rollingop': nn.Linear(embed_dim, len(ACTION_MAP['rollingop'])),
            'pairedrollingop': nn.Linear(embed_dim, len(ACTION_MAP['pairedrollingop'])),
            'Vari': nn.Linear(embed_dim, len(ACTION_MAP['Vari'])),
            'constant': nn.Linear(embed_dim, len(ACTION_MAP['constant'])),
            'num': nn.Linear(embed_dim, len(ACTION_MAP['num'])),
        })
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, expression: str, first_token=None) -> list:
        features = self.feature_extractor(expression)
        
        # 通过两个隐藏层
        features = torch.relu(self.hidden_layer1(features))
        features = torch.relu(self.hidden_layer2(features))

        action_outputs = []

        if first_token == 'E':
            # 当第一个未扩展符号是 'E'，预测类别和具体动作
            category_logits = self.category_head(features)
            category_probs = self.softmax(category_logits).squeeze(0)

            for i, category_prob in enumerate(category_probs):
                category_name = CATEGORY_MAP.get(i)
                if category_name is None:
                    continue
                
                action_head = self.action_heads[category_name]
                action_logits = action_head(features)
                action_probs = self.softmax(action_logits).squeeze(0)

                for j, action_prob in enumerate(action_probs):
                    if category_name == 'constant':
                        action_value = ACTION_MAP['constant'][j]
                    else:
                        action_value = ACTION_MAP[category_name][j]

                    prob = category_prob.item() * action_prob.item()
                    action_outputs.append({
                        'category': category_name,
                        'action': action_value,
                        'prob': prob
                    })
        elif first_token == 'Q':
            category_logits = self.category_head(features)
            category_probs = self.softmax(category_logits).squeeze(0)

            for i, category_prob in enumerate(category_probs):
                category_name = CATEGORY_MAP.get(i)
                if category_name is None:
                    continue
        
                # 直接跳过 constant
                if category_name == 'constant':
                    continue

                # 然后正常处理其余类别
                action_head = self.action_heads[category_name]
                action_logits = action_head(features)
                action_probs = self.softmax(action_logits).squeeze(0)

                for j, action_prob in enumerate(action_probs):
                    action_value = ACTION_MAP[category_name][j]
                    prob = category_prob.item() * action_prob.item()
                    action_outputs.append({
                        'category': category_name,
                        'action': action_value,
                        'prob': prob
                    })
        elif first_token == 'num':
            # 当第一个未扩展符号是 'num'，只预测 num 的值
            if 'num' in self.action_heads:
                action_head = self.action_heads['num']
                action_logits = action_head(features)
                action_probs = self.softmax(action_logits).squeeze(0)

                for j, action_prob in enumerate(action_probs):
                    num_value = ACTION_MAP['num'][j]
                    prob = action_prob.item()
                    action_outputs.append({
                        'category': 'num',
                        'action': num_value,
                        'prob': prob
                    })
            else:
                print("动作头中不存在 'num'")
                return None
        else:
            print(f"无法识别的第一个符号：{first_token}")
            return None

        return action_outputs

def evaluate_policy_network(expression:str, policy_net)->list:
    # 检查表达式是否已经完成
    if 'E' not in expression and 'num' not in expression and 'Q' not in expression:
        #print(f"检测到终止状态: {expression}")
        return None  # 终止状态，返回 None

    try:
        # 创建词汇表
        token_map = create_token_map()
        tokens = parse_expression_to_tokens(expression, token_map)

        first_token = get_first_token(tokens, token_map)

        if first_token is None:
            print(f"无法识别的第一个符号，表达式: {expression}")
            return None

        # 调用策略网络
        action_outputs = policy_net(
            expression,
            first_token=first_token
        )
        
        return action_outputs

    except Exception as e:
        print(f"evaluate_policy_network 出现异常: {e}")
        import traceback
        traceback.print_exc()  # 打印完整的异常堆栈信息
        return None
