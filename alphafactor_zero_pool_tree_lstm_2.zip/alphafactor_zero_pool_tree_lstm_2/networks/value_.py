import torch
import torch.nn as nn

from env.token_v import *
from networks.feature_ import *


class ValueNetwork(nn.Module):
    def __init__(self, feature_extractor, embed_dim):
        super(ValueNetwork, self).__init__()
        self.feature_extractor = feature_extractor
        self.value_head = nn.Sequential(
            nn.Linear(embed_dim, 64),   # 第一个隐藏层，大小为 64
            nn.ReLU(),                   # 激活函数：ReLU
            nn.Linear(64, 64),          # 第二个隐藏层，大小为 64
            nn.ReLU(),                   # 激活函数：ReLU
            nn.Linear(64, 1),            # 输出层，输出一个值
            #nn.Sigmoid()                    # 激活函数：将输出映射到 (-1, 1)
        )

    def forward(self, expression):
        feature = self.feature_extractor(expression)
        value = self.value_head(feature)
        return value


def evaluate_expression_value(expression, value_net):

    value_output = value_net(expression)  # 直接将表达式列表传递到网络

    return value_output.item()


# 测试代码
if __name__ == "__main__":
    expression = "Corr $vwap E num"
    # 初始化特征提取器
    embed_dim = 256
    h_size = 256
    dropout = 0.5
    feature_extractor = FeatureExtractor(
        embed_dim=embed_dim,
        h_size=h_size,
        dropout=dropout,
        pretrained_emb=None
    )

    value_net = ValueNetwork(feature_extractor=feature_extractor, embed_dim=embed_dim)
    value_net.eval()

    value = evaluate_expression_value(expression, value_net)
    print(f"Value after reset: {value:.4f}")