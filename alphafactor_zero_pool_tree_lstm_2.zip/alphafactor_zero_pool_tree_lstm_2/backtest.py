import matplotlib.pyplot as plt
import pandas as pd
from typing import Optional, TypeVar, Callable
import os
import pickle
import warnings

from qlib.backtest import backtest, executor as exec
from qlib.contrib.evaluate import risk_analysis
from qlib.contrib.report.analysis_position import report_graph

from data.expression import *
from data.stock_data import StockData
from data.calculator__ import *
from env.features import *
from strategy_.strategy import TopKSwapNStrategy

_T = TypeVar("_T")

def _create_parents(path: str) -> None:
    dir = os.path.dirname(path)
    if dir != "":
        os.makedirs(dir, exist_ok=True)

def write_all_text(path: str, text: str) -> None:
    _create_parents(path)
    with open(path, "w") as f:
        f.write(text)

def dump_pickle(path: str, factory: Callable[[], _T], invalidate_cache: bool = False) -> Optional[_T]:
    if invalidate_cache or not os.path.exists(path):
        _create_parents(path)
        obj = factory()
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        return obj

class BacktestResult(dict):
    sharpe: float
    annual_return: float
    max_drawdown: float
    information_ratio: float
    annual_excess_return: float
    excess_max_drawdown: float

class QlibBacktest:
    def __init__(
        self,
        benchmark: str = "SH000300",
        top_k: int = 50,
        n_drop: int = 5,
        deal: str = "close",
        open_cost: float = 0.0015,
        close_cost: float = 0.0015,
        min_cost: float = 5
    ):
        self._benchmark = benchmark
        self._top_k = top_k
        self._n_drop = n_drop if n_drop is not None else top_k
        self._deal_price = deal
        self._open_cost = open_cost
        self._close_cost = close_cost
        self._min_cost = min_cost

    def run(
        self,
        prediction: pd.Series,
        output_prefix: Optional[str] = None,
        return_report: bool = False
    ) -> BacktestResult:
        """
        回测并返回结果。
        当 return_report=True 时，返回的是回测的 report DataFrame（包含每日指标），
        否则返回的是最终统计值(BacktestResult)。
        """
        prediction = prediction.sort_index()
        index: pd.MultiIndex = prediction.index.remove_unused_levels()
        dates = index.levels[0]
        portfolio_metric = self.backtest_impl(prediction, dates)
        report, _ = portfolio_metric["1day"]
        result = self._analyze_report(report)
        
        # 画持仓分析图
        graph = report_graph(report, show_notebook=False)[0]

        if output_prefix:
            dump_pickle(output_prefix + "-report.pkl", lambda: report, True)
            dump_pickle(output_prefix + "-graph.pkl", lambda: graph, True)
            write_all_text(output_prefix + "-result.json", result)

        print("=== Report Head ===")
        print(report.head())
        print("=== Backtest Metrics ===")
        print(result)

        if return_report:
            return report
        else:
            return result

    def backtest_impl(self, prediction, dates, last: int = -1):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            strategy = TopKSwapNStrategy(
                K=self._top_k,
                n_swap=self._n_drop,
                signal=prediction,
                min_hold_days=1,
                only_tradable=True
            )
            executor = exec.SimulatorExecutor(
                time_per_step="day", 
                generate_portfolio_metrics=True
            )
            return backtest(
                strategy=strategy,
                executor=executor,
                start_time=dates[0],
                end_time=dates[last],
                account=100_000_000,
                benchmark=self._benchmark,
                exchange_kwargs={
                    "limit_threshold": 0.095,
                    "deal_price": self._deal_price,
                    "open_cost": self._open_cost,
                    "close_cost": self._close_cost,
                    "min_cost": self._min_cost
                }
            )[0]

    def _analyze_report(self, report: pd.DataFrame) -> BacktestResult:
        """
        使用 qlib 自带的风险分析函数，从 report 中提取最终的统计信息（如年化收益、最大回撤等）。
        """
        # 超额收益
        excess = risk_analysis(report["return"] - report["bench"] - report["cost"])["risk"]
        # 总收益
        returns = risk_analysis(report["return"] - report["cost"])["risk"]

        return BacktestResult(
            sharpe=returns.loc["information_ratio"],
            annual_return=returns.loc["annualized_return"],
            max_drawdown=returns.loc["max_drawdown"],
            information_ratio=excess.loc["information_ratio"],
            annual_excess_return=excess.loc["annualized_return"],
            excess_max_drawdown=excess.loc["max_drawdown"]
        )

def compute_cumulative_returns(report: pd.DataFrame) -> pd.Series:
    """
    计算累计收益率:
    - daily_net_ret: 每日净收益 (return - cost)
    - cum_net:       累计收益 (复利计算)
    """
    # 1) 数据检查和预处理
    if not set(["return", "cost"]).issubset(report.columns):
        raise ValueError("report DataFrame must contain 'return' and 'cost' columns.")

    # 排序并重置索引，保证 iloc 对应顺序
    report = report.sort_index().reset_index(drop=True)

    # 2) 计算每日净收益与累计净值
    daily_net_ret = report["return"] - report["cost"]
    cum_net = (1 + daily_net_ret).cumprod()

    return cum_net

def compute_rolling_annualized_returns(report: pd.DataFrame, window: int = 252) -> pd.Series:
    """
    计算滚动年化收益率:
    - daily_net_ret: 每日净收益 (return - cost)
    - cum_net:       累计收益 (复利计算)
    - 对过去 window 天做年化
    """
    # 1) 数据检查和预处理
    if not set(["return", "cost"]).issubset(report.columns):
        raise ValueError("report DataFrame must contain 'return' and 'cost' columns.")

    # 排序并重置索引，保证 iloc 对应顺序
    report = report.sort_index().reset_index(drop=True)

    # 2) 计算每日净收益与累计净值
    daily_net_ret = report["return"] - report["cost"]
    cum_net = (1 + daily_net_ret).cumprod()

    # 创建一个空的结果 Series
    ann_series = pd.Series(index=report.index, dtype=float)

    for i in range(len(cum_net)):
        # 如果当前 i 小于 window，可能选择返回 NaN 或者根据需求做其他处理
        if i < window:
            ann_series.iloc[i] = float("nan")
            continue
        
        # 窗口区间为 [i - window + 1, i]
        start_idx = i - window + 1
        slice_ret = cum_net.iloc[i] / cum_net.iloc[start_idx] - 1

        # 计算年化收益率
        ann_ret = (1.0 + slice_ret) ** (252.0 / window) - 1.0
        ann_series.iloc[i] = ann_ret

    return ann_series


if __name__ == "__main__":
    # 1) 初始化 backtest
    qlib_backtest = QlibBacktest()
    # 初始化数据和目标
    data = StockData(
        instrument="csi300",
        start_time="2020-01-01",
        end_time="2023-12-31",
    )
    close = Feature(FeatureType.CLOSE)
    target = Ref(close, -20) / close - 1
    calculator = QLibStockDataCalculator(data=data, target=target)

    # 2) 定义多个因子表达式
    expr1 = Corr (vwap, low, 30)
    expr2 = Max(Cov(volume, low, 40), 40)
    expr3 = Max(Cov(volume, vwap, 40), 40)
    expr5 = Sub(high,Med((Max(high,40)),40))
    
    exprs1 = [Kurt(Rank(volume,20),20), 
             Delta(low,20), 
             Kurt(Var(vwap,20),40), 
             Kurt(Rank(volume,30),30), 
             Skew(vwap,20), 
             Skew(volume,40), 
             Pow(low,Mad(Constant(-0.1),30)), 
             Pow(low,Log(Constant(0.05))), 
             Add(volume,Add(volume,Add(volume,Mul(vwap,volume)))), 
             Kurt(Mean(vwap,30),40), 
             Mad(high,40), 
             Kurt(Kurt(low,20),20), 
             Abs(CSRank(high)), 
             Pow(Kurt(low,20),Constant(-0.01)), 
             Kurt(Kurt(volume,20),40), 
             Kurt(Skew(open,40),40), 
             Log(Log(volume)), 
             Delta(close,30), 
             Pow(low,Rank(vwap,40)), 
             Kurt(Delta(vwap,20),40)]
    
    list1 =  [-0.01030524048449725, 
             -0.011550927293341626, 
             0.006859926504326921, 
             -0.007449764445756863, 
             -0.007773054784818577, 
             -0.013030424384269223, 
             -0.0075302906502860405, 
             0.0143912592183576, 
             -0.01192518150313953, 
             -0.008732184126467172, 
             0.02791262183985019, 
             -0.007261620410919403, 
             -0.034269137806232176, 
             -0.01028188043963289, 
             -0.009561790113982319, 
             -0.006897632838328073, 
             -0.04657314665818183, 
             -0.010724798893941113, 
             -0.010751729983825646, 
             -0.014701513927698681]
    
    exprs2 = [
        Div(Ref(Ref(Sub(Div(Log(low), Constant(2.0)), low), 20), 50), Constant(-1.0)),
        Div(open, Sub(Div(high, Constant(-2.0)), Ref(Div(Div(Constant(1.0), Std(Div(close, Constant(0.5)), 20)), Constant(2.0)), 20))),
        Sub(Sub(Sub(Cov(Med(Sub(Constant(5.0), Med(open, 20)), 20), open, 20), Constant(10.0)), open), Constant(10.0)),
        Add(Std(Sub(Greater(Greater(volume, Constant(0.01)), close), Delta(Sum(volume, 40), 10)), 40), close),
        Max(Div(Div(Mul(Constant(30.0), Std(high, 10)), Constant(-1.0)), Constant(2.0)), 20),
        Add(Greater(Div(Constant(-2.0), open), Constant(-1.0)), Corr(close, vwap, 10)),
        Div(Constant(0.5), Div(volume, Div(Div(Constant(0.5), Div(Div(Div(Greater(high, Constant(0.01)), Delta(low, 10)), Constant(0.5)), Constant(0.5))), vwap))),
       Var(Var(Div(close, high), 40), 40),
        Div(low, Min(Mul(Constant(-1.0), high), 20)),
        Sub(Constant(1.0), Ref(Ref(Div(Less(close, Constant(10.0)), Log(high)), 40), 20)),
        Mul(Div(Mul(Constant(-30.0), Med(Ref(Med(volume, 30), 50), 20)), Constant(30.0)), Constant(2.0)),
        Var(Sub(Less(Log(Div(Less(close, high), Constant(30.0))), high), Constant(30.0)), 50),
        Sub(Div(Var(Add(Sub(Greater(Add(Greater(Constant(0.5), Mul(close, Constant(10.0))), close), high), Constant(30.0)), Constant(30.0)), 40), high), Constant(10.0)),
        Sub(Less(EMA(Add(Constant(-5.0), low), 10), Constant(-1.0)), Delta(Abs(Abs(EMA(Div(low, Div(Constant(-1.0), high)), 40))), 10)),
        Div(Div(Div(Sub(Constant(1.0), WMA(close, 50)), Constant(-1.0)), close), Constant(-1.0)),
        Var(Div(Sub(Ref(open, 40), high), Sub(Constant(-10.0), open)), 40),
        Div(Div(Div(Sub(Min(Sub(Ref(Div(Div(Constant(0.5), low), high), 10), close), 20), Constant(5.0)), Constant(-0.5)), close), Constant(5.0)),
        Div(Min(Div(Div(Ref(Div(Min(Ref(Sub(Constant(0.5), low), 30), 20), high), 20), Constant(2.0)), Constant(0.01)), 20), Constant(10.0)),
        Div(Div(Sub(Div(Sub(Div(Less(Constant(30.0), Add(close, Constant(-10.0))), close), Constant(2.0)), Constant(-30.0)), Constant(2.0)), Constant(30.0)), Constant(-30.0)),
        WMA(Ref(Std(Div(Div(low, Constant(-2.0)), Constant(-1.0)), 20), 50), 20)
    ]



    list2 = [
        0.09502141695667261,
        -0.04284838243683415,
        0.046478180960363394,
        -0.05042700796134904,
        0.03105340639775257,
        0.05600541398648118,
        0.03166065348900709,
        -0.027519993945766118,
        -0.035485036236453465,
        0.037641499842031946,
        -0.02693215372832377,
        0.04735662555474109,
        0.037579451244504625,
        -0.02927619639891235,
        -0.10095333070030257,
        -0.033308933884419495,
        0.13429881628498438,
        0.03668958317985003,
        -0.05450648007505799,
        -0.04412764877556755
    ]




    # 4) 分别计算每个因子的因子值
    data_df1 = data.make_dataframe(expr1.evaluate(data))
    data_df2 = data.make_dataframe(expr2.evaluate(data))
    data_df3 = data.make_dataframe(QLibStockDataCalculator(data, None).make_ensemble_alpha(exprs2, list2))
    data_df4 = data.make_dataframe(QLibStockDataCalculator(data, None).make_ensemble_alpha(exprs1, list1))


    # 5) 分别跑 4 次回测，得到 4 个 report
    report1 = qlib_backtest.run(data_df1, return_report=True)
    report2 = qlib_backtest.run(data_df2, return_report=True)
    report3 = qlib_backtest.run(data_df3, return_report=True)
    report4 = qlib_backtest.run(data_df4, return_report=True)


    # 6) 分别把 4 个 report 转换为 4 条“滚动年化收益率”曲线
    annual_ts_1 = compute_rolling_annualized_returns(report1, window=252)
    annual_ts_2 = compute_rolling_annualized_returns(report2, window=252)
    annual_ts_3 = compute_rolling_annualized_returns(report3, window=252)
    annual_ts_4 = compute_rolling_annualized_returns(report4, window=252)


    cum_ts_1 = compute_cumulative_returns(report1)
    cum_ts_2 = compute_cumulative_returns(report2)
    cum_ts_3 = compute_cumulative_returns(report3)
    cum_ts_4 = compute_cumulative_returns(report4)
    # 7) 在同一张图上绘制并保存
    # 年化收益率绘制
    plt.figure(figsize=(12, 6))
    plt.plot(annual_ts_1.index, annual_ts_1, label='Corr (vwap, low, 30) Annual Returns')
    plt.plot(annual_ts_2.index, annual_ts_2, label='Max(Cov(volume, vwap, 40), 40) Annual Returns')
    plt.plot(annual_ts_3.index, annual_ts_3, label='ppo-pool-alpha Annual Returns')
    plt.plot(annual_ts_4.index, annual_ts_4, label='pool-alpha Annual Returns')
    plt.title("Comparison of Rolling Annualized Returns - 4 Factors")
    plt.xlabel("Date")
    plt.ylabel("Annual Return (%)")
    plt.legend()
    plt.grid(True)
    plt.savefig("./comparison_annual_returns.png", dpi=300)
    plt.show()

    # 累计收益绘制
    plt.figure(figsize=(12, 6))
    plt.plot(cum_ts_1.index, cum_ts_1, label='Corr (vwap, low, 30) Cumulative Returns')
    plt.plot(cum_ts_2.index, cum_ts_2, label='Max(Cov(volume, vwap, 40), 40) Cumulative Returns')
    plt.plot(cum_ts_3.index, cum_ts_3, label='ppo-pool-alpha Cumulative Returns')
    plt.plot(cum_ts_4.index, cum_ts_4, label='pool-alpha Cumulative Returns')
    plt.title("Comparison of Cumulative Returns - 4 Factors")
    plt.xlabel("Date")
    plt.ylabel("Cumulative Return")
    plt.legend()
    plt.grid(True)
    plt.savefig("./comparison_cumulative_returns.png", dpi=300)
    plt.show()