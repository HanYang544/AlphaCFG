import random

class AlphaEnv:
    def __init__(self, seed=None):
        # === 1) 操作符分类（贴近您原先的写法），仅拆分了 Sub1/Sub2、Div1/Div2、Pow1/Pow2 ===
        self.unary_operators = ['Log','Abs','Sign','CSRank'] 
        self.binary_operators = [
            'Add', 
            'Sub1','Sub2',
            'Mul', 
            'Div1','Div2',
            'Pow1','Pow2',
            'Greater', 
            'Less'
        ]
        self.rolling_operators = [
            'Ref','Skew','Kurt','Mean','Sum','Std','Var',
            'Max','Min','Med','Rank','Mad','Delta','WMA'
            # 若需要 'EMA' 等，可自行加回
        ]
        self.paired_rolling_operators = ['Cov','Corr']
        
        # === 2) 特征列表（E->high/low/...  与 Q->high/low/...）===
        self.features = ['high','low','volume','open','close','vwap']

        # === 3) 常量/数值范围，与您原先保持一致 ===
        self.constants = [-0.1, -0.05, -0.01, 0.01, 0.05, 0.1]
        self.num_range = [20, 30, 40]

        # === 4) 随机种子 ===
        self.seed = seed
        if seed is not None:
            random.seed(seed)

        # === 5) 初始状态只包含一个 E（开始符号）===
        self.state = ['Q']
        self.expansion_depth = 0

    def reset(self):
        """重置环境：恢复到只含有起始符 E"""
        self.state = ['Q']
        self.expansion_depth = 0
        return self.state

    def get_possible_actions(self):
        """
        根据当前状态 (self.state) 中最先出现的占位符 (E/Q/num) 决定可用的动作类别。
        
        - 若遇到 'E'，可用的类别：unaryop, binaryop, rollingop, pairedrollingop, Vari, constant
        - 若遇到 'Q'，可用的类别：unaryop, binaryop, rollingop, pairedrollingop, Vari
          (不包含 'constant'，因为在文法中 Q->constant(float) 并不存在)
        - 若遇到 'num'，可用的类别：['num'] (用于替换成具体整数)
        - 若均无，则表达式已完成
        """
        for element in self.state:
            if 'E' in element:
                # 如果字符串里含有 'E' (比如 "E" 或 "Add Q E")，则可以展开 E
                return ['unaryop', 'binaryop', 'rollingop', 'pairedrollingop', 'Vari', 'constant']
            
            elif 'Q' in element:
                # 如果含有 'Q'，则可以展开 Q
                return ['unaryop', 'binaryop', 'rollingop', 'pairedrollingop', 'Vari']
            
            elif 'num' in element:
                # 如果含有 'num'，可以替换为具体数字
                return ['num']
        
        # 若都不含 E/Q/num，表达式完成
        return []

    def apply_action(self, action_category, action):
        """
        以与您原先相同的方式进行交互：传入 (action_category, action)，
        例如 ('binaryop', 'Add') 或 ('rollingop', 'Ref') 等。
        """
        new_state, reward, done, info = self.step(action_category, action)
        return self, reward, done, info

    def step(self, action_category, action):
        new_state = []
        expanded = False

        # 从左到右逐字符检查
        for element in self.state:
            if not expanded:
                pos_E = element.find('E') if 'E' in element else float('inf')
                pos_Q = element.find('Q') if 'Q' in element else float('inf')
                pos_num = element.find('num') if 'num' in element else float('inf')

                # 找到最靠左的非终结符号
                min_pos = min(pos_E, pos_Q, pos_num)

                if min_pos == float('inf'):
                    # 当前element无非终结符
                    new_state.append(element)
                    continue

                # 根据最左侧非终结符进行替换
                if min_pos == pos_E:
                    symbol = 'E'
                elif min_pos == pos_Q:
                    symbol = 'Q'
                else:
                    symbol = 'num'

                expanded = True
                if symbol in ('E', 'Q'):
                    new_elements = self._expand_element(element, symbol=symbol,
                                                        action_category=action_category,
                                                        action=action)
                    new_state.extend(new_elements)
                else:  # num
                    replaced = element.replace('num', str(action), 1)
                    new_state.append(replaced)

                self.expansion_depth += 1
            else:
                new_state.append(element)

        self.state = new_state

        done = all(('E' not in elem and 'Q' not in elem and 'num' not in elem) for elem in self.state)

        return self.state, 0, done, {'depth': self.expansion_depth}


    def _expand_element(self, element, symbol, action_category, action):
        """
        在给定的 element(字符串) 中，将 'E' 或 'Q' 的**第一个**出现替换为相应的产生式右部。
        
        - symbol='E' 表示要执行 "E -> ..." 的某条规则
        - symbol='Q' 表示 "Q -> ..." 的某条规则
        """
        if symbol == 'E':
            expansion_str = self._expand_for_E(action_category, action)
            # 只替换第一个 'E'
            replaced = element.replace('E', expansion_str, 1)
            return [replaced]

        elif symbol == 'Q':
            expansion_str = self._expand_for_Q(action_category, action)
            replaced = element.replace('Q', expansion_str, 1)
            return [replaced]
        
        # 正常不会进到这
        return [element]

    # ============== 不同符号(E/Q)的展开逻辑 ==============

    def _expand_for_E(self, action_category, action):
        """
        针对 E 的文法，如：
          E->Abs(Q), E->Add(Q,E), E->Ref(Q,num), E->Delta(E,num), E->Cov(Q,E,num), E->high, E->constant(float) ...
        由于您原先使用类似 'Abs E'/'Add E E' 这样的写法，
        这里根据文法变为 'Abs Q'/'Add Q E'/'Ref Q num'/'Delta E num' 等。
        """
        if action_category == 'unaryop':
            # 文法: E->Abs(Q), E->Sign(Q), E->Log(Q), E->CSRank(Q)
            # 我们用形如 "Abs Q" 来替换
            if action == 'Abs':
                return "Abs Q"
            elif action == 'Sign':
                return "Sign Q"
            elif action == 'Log':
                return "Log Q"
            elif action == 'CSRank':
                return "CSRank Q"
            else:
                # 兜底：未列出的 unary
                return f"{action} Q"

        elif action_category == 'binaryop':
            # 文法: E->Add(Q,E), E->Sub1(Q,E), E->Sub2(E,Q), ...
            # 这意味着展开后是类似 "Add Q E" 或 "Sub2 E Q" 的写法
            if action == 'Add':
                return "Add Q E"
            elif action == 'Sub1':
                return "Sub1 Q E"
            elif action == 'Sub2':
                return "Sub2 E Q"
            elif action == 'Mul':
                return "Mul Q E"
            elif action == 'Div1':
                return "Div1 Q E"
            elif action == 'Div2':
                return "Div2 E Q"
            elif action == 'Pow1':
                return "Pow1 Q E"
            elif action == 'Pow2':
                return "Pow2 E Q"
            elif action == 'Greater':
                return "Greater Q E"
            elif action == 'Less':
                return "Less Q E"
            else:
                return f"{action} Q E"

        elif action_category == 'rollingop':
            # 文法: E->Ref(Q,Num), E->Mean(Q,Num), ..., E->Delta(E,Num), ...
            # 在无括号、无逗号写法下示例: "Ref Q num", "Mean Q num", "Delta E num"
            if action == 'Ref':
                return "Ref Q num"
            elif action == 'Mean':
                return "Mean Q num"
            elif action == 'Sum':
                return "Sum Q num"
            elif action == 'Std':
                return "Std Q num"
            elif action == 'Var':
                return "Var Q num"
            elif action == 'Skew':
                return "Skew Q num"
            elif action == 'Kurt':
                return "Kurt Q num"
            elif action == 'Max':
                return "Max Q num"
            elif action == 'Min':
                return "Min Q num"
            elif action == 'Med':
                return "Med Q num"
            elif action == 'Mad':
                return "Mad Q num"
            elif action == 'Rank':
                return "Rank Q num"
            elif action == 'Delta':
                return "Delta Q num"
            elif action == 'WMA':
                return "WMA Q num"
            # 其它 rollingop (如 'EMA') 如果需要请加上
            else:
                return f"{action} Q num"

        elif action_category == 'pairedrollingop':
            # E->Cov(Q,E,Num), E->Corr(Q,E,Num)
            if action == 'Cov':
                return "Cov Q E num"
            elif action == 'Corr':
                return "Corr Q E num"
            else:
                return f"{action} Q E num"

        elif action_category == 'Vari':
            # E->high / E->low / ...
            # 这里直接返回特征字符串
            return f"${action}"

        elif action_category == 'constant':
            # E->constant(float)
            # 这里原先您是直接用 str(action) 替换
            return str(action)

        # 未知类别
        return f"{action} Q E"

    def _expand_for_Q(self, action_category, action):
        """
        针对 Q 的文法，如：
          Q->Abs(Q), Q->Add(Q,E), Q->Ref(Q,num), Q->Delta(Q,Num), Q->Cov(Q,E,Num), Q->high, ...
        与 E 的差异主要在:
          - Q->Delta(Q,Num) 而非 Delta(E,Num)
          - Q 没有直接 -> constant(float)
        """
        if action_category == 'unaryop':
            # Q->Abs(Q), Q->Sign(Q), Q->Log(Q), Q->CSRank(Q)
            if action == 'Abs':
                return "Abs Q"
            elif action == 'Sign':
                return "Sign Q"
            elif action == 'Log':
                return "Log Q"
            elif action == 'CSRank':
                return "CSRank Q"
            else:
                return f"{action} Q"

        elif action_category == 'binaryop':
            # Q->Add(Q,E), Q->Sub1(Q,E), Q->Sub2(E,Q), ...
            if action == 'Add':
                return "Add Q E"
            elif action == 'Sub1':
                return "Sub1 Q E"
            elif action == 'Sub2':
                return "Sub2 E Q"
            elif action == 'Mul':
                return "Mul Q E"
            elif action == 'Div1':
                return "Div1 Q E"
            elif action == 'Div2':
                return "Div2 E Q"
            elif action == 'Pow1':
                return "Pow1 Q E"
            elif action == 'Pow2':
                return "Pow2 E Q"
            elif action == 'Greater':
                return "Greater Q E"
            elif action == 'Less':
                return "Less Q E"
            else:
                return f"{action} Q E"

        elif action_category == 'rollingop':
            # Q->Ref(Q,Num), Q->Mean(Q,Num), ..., Q->Delta(Q,Num)
            if action == 'Ref':
                return "Ref Q num"
            elif action == 'Mean':
                return "Mean Q num"
            elif action == 'Sum':
                return "Sum Q num"
            elif action == 'Std':
                return "Std Q num"
            elif action == 'Var':
                return "Var Q num"
            elif action == 'Skew':
                return "Skew Q num"
            elif action == 'Kurt':
                return "Kurt Q num"
            elif action == 'Max':
                return "Max Q num"
            elif action == 'Min':
                return "Min Q num"
            elif action == 'Med':
                return "Med Q num"
            elif action == 'Mad':
                return "Mad Q num"
            elif action == 'Rank':
                return "Rank Q num"
            elif action == 'Delta':
                return "Delta Q num"
            elif action == 'WMA':
                return "WMA Q num"
            else:
                return f"{action} Q num"

        elif action_category == 'pairedrollingop':
            # Q->Cov(Q,E,Num), Q->Corr(Q,E,Num)
            if action == 'Cov':
                return "Cov Q E num"
            elif action == 'Corr':
                return "Corr Q E num"
            else:
                return f"{action} Q E num"

        elif action_category == 'Vari':
            # Q-> high / low / ...
            return f"${action}"

        elif action_category == 'constant':
            # 文法中无 Q->constant(float)，所以通常不会走到这里
            # 但为了安全，给个兜底
            return str(action)

        # 未知类别
        return f"{action} Q E"

    # ============== 其它辅助方法与您原先保持一致 ==============

    def render(self):
        """输出当前表达式"""
        print("当前表达式：", ' '.join(self.state))

    def state_description(self):
        """返回当前状态的描述"""
        return ' '.join(self.state)
    
    def is_terminal_state(self):
        """没有 E/Q/num 时，为终止状态。"""
        return all(
            ('E' not in elem) and 
            ('Q' not in elem) and
            ('num' not in elem)
            for elem in self.state
        )



# ===================== 测试示例 =====================
if __name__ == "__main__":
    env = AlphaEnv()
    env.reset()
    print("[初始化] state:", env.state_description())

    # (1) 对 E 应用一个 binaryop: 'Add' => E->Add(Q,E)
    env.apply_action('binaryop', 'Add')
    print("[E->Add(Q,E)] state:", env.state_description())

    # (2) 现在 state = ["Add Q E"]
    #     第一个占位符是 Q => 选一元操作符 'Log' => Q->Log(Q)
    env.apply_action('unaryop', 'Log')
    print("[Q->Log(Q)] state:", env.state_description())

    # (3) state = ["Add Log Q E"]
    #     第一个占位符是 Q => 变成 'close' => Q->close
    env.apply_action('Vari', 'close')
    print("[Q->close] state:", env.state_description())

    # (4) state = ["Add Log close E"]
    #     现在第一个占位符是 E => rollingop 'Mean' => E->Mean(Q,num)
    env.apply_action('rollingop', 'Mean')
    print("[E->Mean(Q,num)] state:", env.state_description())

    # (5) state = ["Add Log close Mean Q num"]
    #     第一个占位符是 Q => 用 'Vari' => 'high'
    env.apply_action('Vari', 'high')
    print("[Q->high] state:", env.state_description())

    # (6) state = ["Add Log close Mean high num"]
    #     最后一个占位符是 'num' => 替换成 30
    env.apply_action('num', 30)
    print("[num->30] state:", env.state_description())

    # state = ["Add Log close Mean high 30"] 不含 E/Q/num => done
    print("表达式完成:", env.state_description())
    print("is_terminal_state?", env.is_terminal_state())
