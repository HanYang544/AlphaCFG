import re

def create_token_map():
    token_map = {}

    # ========== 1) Unary operators ==========
    token_map['Log'] = 1
    token_map['Abs'] = 2
    token_map['Sign'] = 3
    token_map['CSRank'] = 4

    # ========== 2) Binary operators ==========
    token_map['Add'] = 5
    token_map['Sub1'] = 6
    token_map['Sub2'] = 7
    token_map['Mul'] = 8
    token_map['Div1'] = 9
    token_map['Div2'] = 10
    token_map['Pow1'] = 11
    token_map['Pow2'] = 12
    token_map['Greater'] = 13
    token_map['Less'] = 14

    # ========== 3) Rolling operators ==========
    token_map['Ref'] = 15
    token_map['Skew'] = 16
    token_map['Kurt'] = 17
    token_map['Mean'] = 18
    token_map['Sum'] = 19
    token_map['Std'] = 20
    token_map['Var'] = 21
    token_map['Max'] = 22
    token_map['Min'] = 23
    token_map['Med'] = 24
    token_map['Rank'] = 25
    token_map['Mad'] = 26
    token_map['Delta'] = 27
    token_map['WMA'] = 28

    # ========== 4) Paired rolling operators ==========
    token_map['Cov'] = 29
    token_map['Corr'] = 30

    # ========== 5) Features ==========
    token_map['$high'] = 31
    token_map['$low'] = 32
    token_map['$volume'] = 33
    token_map['$open'] = 34
    token_map['$close'] = 35
    token_map['$vwap'] = 36

    # ========== 6) Special tokens ==========
    token_map['E'] = 37         # 非终结符 E
    token_map['Q'] = 38         # 非终结符 Q
    token_map['num'] = 39       # 用于占位数字

    # ========== 7) Constants ==========
    token_map['-0.1'] = 40
    token_map['-0.05'] = 41
    token_map['-0.01'] = 42
    token_map['0.01'] = 43
    token_map['0.05'] = 44
    token_map['0.1'] = 45

    # ========== 8) Numbers (num_range) ==========
    token_map['40'] = 46
    token_map['30'] = 47
    token_map['20'] = 48

    return token_map


def parse_expression_to_tokens(expression, token_map):
    # Updated regex to capture negative floats and predefined nums
    tokens = re.findall(r'[-]?\d+\.\d+|\$?\b\w+\b|[-]?\d+', expression)
    token_sequence = []
    for token in tokens:
        if token in token_map:
            token_sequence.append(token_map[token])
        elif re.match(r'\$[a-zA-Z]+', token):  # Variable, e.g., $high
            token_sequence.append(token_map.get(token, token_map.get('Vari', 0)))
        elif re.match(r'[-]?\d+(\.\d+)?', token):  # Numbers, including predefined
            # Check if the number is in the predefined constants or num
            if token in token_map:
                token_sequence.append(token_map[token])
            else:
                print(f"未识别的数字: {token}")
                token_sequence.append(token_map['constant'])
        else:
            print(f"未识别的标记: {token}")
            token_sequence.append(0)  # Use 0 for undefined tokens
    return token_sequence


def get_first_token(expression_tokens, token_map):
    inverse_token_map = {v: k for k, v in token_map.items()}
    for token_id in expression_tokens:
        token = inverse_token_map.get(token_id)
        if token == 'E':
            return 'E'
        elif token == 'Q':
            return 'Q'
        elif token == 'num':
            return 'num'
    return None


# ===== 测试示例 =====
if __name__ == "__main__":
    token_map = create_token_map()

    test_expressions = [
        "Add close Log Mean high 30",
        "Sub1 open Abs E",
        "Ref volume Delta E 20",
        "Corr low Var Q",
        "Pow1 close CSRank Q"
    ]

    for i, expr in enumerate(test_expressions, 1):
        tokens = parse_expression_to_tokens(expr, token_map)
        first_token = get_first_token(tokens, token_map)
        print(f"【测试实例 {i}】")
        print("表达式:", expr)
        print("token序列:", tokens)
        print("首个占位符:", first_token)
        print("-" * 40)
