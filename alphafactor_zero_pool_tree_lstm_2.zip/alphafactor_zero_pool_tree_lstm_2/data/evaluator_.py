import torch
from data.stock_data import *
from data.calculator__ import *
from data.expression import *
import multiprocessing
from joblib import Parallel, delayed


# 设置多进程的启动方法为 'spawn'
multiprocessing.set_start_method('spawn', force=True)


def parse_expression_from_string(expression_str: str) -> Expression:
    """
    解析前缀表示法的表达式字符串，返回 Expression 对象。

    参数:
    - expression_str: str, 前缀表示法的表达式，例如 "Add $high $low"

    返回:
    - Expression 对象
    """
    tokens = expression_str.split()
    tokens = tokens[::-1]  # 反转列表，方便使用 pop() 从末尾获取

    def parse() -> Expression:
        if not tokens:
            raise ValueError("无效的表达式：缺少令牌。")
        token = tokens.pop()

        # 二元操作符 (将带后缀的操作符统一转换为基础形式)
        if token in ['Add', 'Sub', 'Sub1', 'Sub2', 'Mul', 'Div', 'Div1', 'Div2', 
                     'Greater', 'Less', 'Pow', 'Pow1', 'Pow2']:
            # 如果 token 后缀为 '1' 或 '2'，则去掉后缀
            if token.endswith('1') or token.endswith('2'):
                base_token = token[:-1]
            else:
                base_token = token
            left = parse()
            right = parse()
            operator_map = {
                'Add': Add,
                'Sub': Sub,
                'Mul': Mul,
                'Div': Div,
                'Greater': Greater,
                'Less': Less,
                'Pow': Pow
            }
            return operator_map[base_token](left, right)

        # 一元操作符
        elif token in ['Abs', 'Sign', 'Log', 'CSRank']:
            operand = parse()
            operator_map = {
                'Abs': Abs,
                'Sign': Sign,
                'Log': Log,
                'CSRank': CSRank
            }
            return operator_map[token](operand)

        # 滚动操作符
        elif token in ['Ref', 'Mean', 'Sum', 'Std', 'Var', 'Skew', 'Kurt', 'Max', 'Min', 
                       'Med', 'Mad', 'Rank', 'Delta', 'WMA', 'EMA']:
            operand = parse()
            delta_time_token = tokens.pop()
            try:
                delta_time = int(delta_time_token)
            except ValueError:
                raise ValueError(f"无效的 delta_time 值: {delta_time_token}")
            operator_map = {
                'Ref': Ref,
                'Mean': Mean,
                'Sum': Sum,
                'Std': Std,
                'Var': Var,
                'Skew': Skew,
                'Kurt': Kurt,
                'Max': Max,
                'Min': Min,
                'Med': Med,
                'Mad': Mad,
                'Rank': Rank,
                'Delta': Delta,
                'WMA': WMA,
                'EMA': EMA
            }
            return operator_map[token](operand, delta_time)

        # 成对滚动操作符
        elif token in ['Cov', 'Corr']:
            lhs = parse()
            rhs = parse()
            delta_time_token = tokens.pop()
            try:
                delta_time = int(delta_time_token)
            except ValueError:
                raise ValueError(f"无效的 delta_time 值: {delta_time_token}")
            operator_map = {
                'Cov': Cov,
                'Corr': Corr
            }
            return operator_map[token](lhs, rhs, delta_time)

        # 特征变量
        elif token.startswith('$'):
            feature_name = token[1:].upper()  # 假设 FeatureType 的名称为大写
            try:
                feature = FeatureType[feature_name]
            except KeyError:
                raise ValueError(f"未知的特征变量: {feature_name}")
            return Feature(feature)

        # 常量
        else:
            try:
                value = float(token)
                return Constant(value)
            except ValueError:
                raise ValueError(f"未知的令牌或无效的常量: {token}")

    expression = parse()
    if tokens:
        raise ValueError("无效的表达式：存在多余的令牌。")
    return expression



def evaluate_expression_ic_train(expr: Expression) -> float:
    """
    计算给定表达式的 IC 值。

    参数:
    - expr: Expression 对象，表示需要评估的因子表达式

    返回:
    - IC 值（float）
    """
    # 初始化 StockData，使用一个更长时间范围
    stock_data = StockData(
        instrument="csi100",
        start_time="2009-01-01",  # 扩大时间范围
        end_time="2018-01-01",
        features=[FeatureType.OPEN, FeatureType.CLOSE, FeatureType.HIGH, FeatureType.LOW, FeatureType.VOLUME, FeatureType.VWAP],
        device=torch.device('cuda:1'),
        max_backtrack_days=800,
        max_future_days=400
    )

    # 定义目标因子
    close = Feature(FeatureType.CLOSE)
    target = Ref(close, -20) / close - 1

    # 使用 QLibStockDataCalculator 计算表达式的 IC
    calculator = QLibStockDataCalculator(data=stock_data, target=target)

    # 计算 IC 值
    ic_value = calculator.calc_single_IC_ret(expr)

    return ic_value

def evaluate_expression_ic_valid(expr: Expression) -> float:
    """
    计算给定表达式的 IC 值。

    参数:
    - expr: Expression 对象，表示需要评估的因子表达式

    返回:
    - IC 值（float）
    """
    # 初始化 StockData，使用一个更长时间范围
    stock_data = StockData(
        instrument="csi100",
        start_time="2019-01-01",  # 扩大时间范围
        end_time="2019-12-31",
        features=[FeatureType.OPEN, FeatureType.CLOSE, FeatureType.HIGH, FeatureType.LOW, FeatureType.VOLUME, FeatureType.VWAP],
        device=torch.device('cuda:1'),
        max_backtrack_days=800,
        max_future_days=400
    )

    # 定义目标因子
    close = Feature(FeatureType.CLOSE)
    target = Ref(close, -20) / close - 1

    # 使用 QLibStockDataCalculator 计算表达式的 IC
    calculator = QLibStockDataCalculator(data=stock_data, target=target)

    # 计算 IC 值
    ic_value = calculator.calc_single_IC_ret(expr)

    return ic_value


def parallel_evaluate_ic_train(expressions,n_jobs):
    """
    使用joblib的并行计算方法计算多个表达式的IC值，避免并行计算嵌套。

    参数:
    - expressions: list, 表达式对象的列表

    返回:
    - results: list, 对应表达式的IC值列表
    """
    # 设置进程启动方法为 'spawn'，避免多进程间的兼容性问题
    multiprocessing.set_start_method('spawn', force=True)

    # 使用线程后端避免多进程嵌套问题
    results = Parallel(n_jobs=n_jobs, backend='multiprocessing')(delayed(evaluate_expression_ic_train)(expr) for expr in expressions)

    
    return results

def parallel_evaluate_ic_valid(expressions,n_jobs):
    """
    使用joblib的并行计算方法计算多个表达式的IC值，避免并行计算嵌套。

    参数:
    - expressions: list, 表达式对象的列表

    返回:
    - results: list, 对应表达式的IC值列表
    """
    # 设置进程启动方法为 'spawn'，避免多进程间的兼容性问题
    multiprocessing.set_start_method('spawn', force=True)

    # 使用线程后端避免多进程嵌套问题
    results = Parallel(n_jobs=n_jobs, backend='multiprocessing')(delayed(evaluate_expression_ic_valid)(expr) for expr in expressions)

    
    return results










