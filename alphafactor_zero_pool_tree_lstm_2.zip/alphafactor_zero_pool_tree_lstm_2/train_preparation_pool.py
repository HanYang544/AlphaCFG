# train_preparation.py

import math
import torch
import torch.nn as nn
import torch.optim as optim
import torch.multiprocessing as mp

import copy
import os
import random
import numpy as np
import pandas as pd
import json
import csv
import logging
from collections import deque
from functools import partial

from torch.nn.utils.rnn import pad_sequence  # <-- 用于做padding

from mcts import MCTS, Node
from networks.policy_ import PolicyNetwork, evaluate_policy_network, ACTION_MAP, CATEGORY_MAP
from networks.value_ import ValueNetwork, evaluate_expression_value
from env.alpha_env import AlphaEnv
from env.token_v import create_token_map, parse_expression_to_tokens, get_first_token
from data.evaluator_ import *
from data.calculator__ import *
#from models.linear_alpha_pool import MseAlphaPool
from networks.feature_ import FeatureExtractor

# 设置多进程的启动方法为 'spawn'
mp.set_start_method('spawn', force=True)

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


#####################################
#           ReplayBuffer            #
#####################################
class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)
        self.current_index = 0  # 用于顺序采样的起始位置

    def push(self, expression, action_probs_list, value):
        """
        将数据存入缓冲区
        """
        self.buffer.append((expression, action_probs_list, value))
    
    def sample(self, batch_size):
        """
        随机采样：从缓冲区中随机选取 batch_size 条数据。
        当缓冲区样本数量不足 batch_size 时，使用有放回采样以确保返回 batch_size 条数据。
        """
        if len(self.buffer) == 0:
            return []
        buffer_list = list(self.buffer)
        if len(buffer_list) < batch_size:
            return random.choices(buffer_list, k=batch_size)
        else:
            return random.sample(buffer_list, batch_size)

    def __len__(self):
        return len(self.buffer)


#####################################
#     mcts_policy_to_target         #
#####################################
def mcts_policy_to_target(action_probs_dict):
    """
    将 MCTS 生成的动作概率字典 {('unaryop','Abs'): p, ...}
    转为 [{'category': c, 'action': a, 'prob': p}, ...]
    仅添加存在概率的动作，找不到概率的则跳过。
    """
    target_policy = []
    for category, actions in ACTION_MAP.items():
        for action in actions:
            if (category, action) in action_probs_dict:
                prob = action_probs_dict[(category, action)]
                target_policy.append({
                    'category': category,
                    'action': action,
                    'prob': prob
                })
    return target_policy 

#####################################
#     compute_policy_loss           #
#####################################
def compute_policy_loss(action_outputs, target_policy, classification_loss_fn, device):
    """
    计算策略网络输出与目标策略之间的 KL 散度损失
    """
    num_categories = action_outputs.shape[0]
    target_distribution = torch.zeros(num_categories, device=device)

    category_idx = 0
    for category, actions in ACTION_MAP.items():
        for action in actions:
            if category_idx >= num_categories:
                break
            prob = next((item['prob'] for item in target_policy
                         if item['category'] == category and item['action'] == action), 0.0)
            target_distribution[category_idx] = prob
            category_idx += 1

    # 归一化目标分布
    if target_distribution.sum() > 0:
        target_distribution /= target_distribution.sum()

    # 将网络输出做 softmax
    output_distribution = torch.softmax(action_outputs, dim=0)

    # 计算 KL 散度
    loss = classification_loss_fn(torch.log(output_distribution + 1e-10), target_distribution)
    return loss


#####################################
#        顺序批量训练 - policy      #
#####################################
def train_policy_net(policy_net, optimizer, replay_buffer, num_batches, batch_size, device):
    """
    1. 顺序采样 batch_size 条数据（直到把缓冲区数据遍历完）。
    2. 做 padding 对齐 states。
    3. 前向传播、计算损失并反向传播。
    """
    policy_net.train()
    classification_loss_fn = nn.KLDivLoss(reduction='batchmean')
    total_policy_loss = 0.0
    valid_samples = 0

    num_data = len(replay_buffer)
    if num_data == 0:
        return 0.0

    for _ in range(num_batches):
        batch_data = replay_buffer.sample(batch_size)
        if not batch_data:
            continue

        # 拆分出 states、action_probs_list、values、expressions
        expressions, action_probs_list, _ = zip(*batch_data)

        # 对一个 batch 里所有数据一起算 loss
        optimizer.zero_grad()
        policy_loss = torch.tensor(0.0, device=device, requires_grad=True)

        for i in range(len(batch_data)):
            # 当前样本的目标策略
            target_policy = action_probs_list[i]
            if not target_policy:
                continue

            tokens = parse_expression_to_tokens(expressions[i], create_token_map())
            first_token = get_first_token(tokens, create_token_map())
            if first_token is None:
                continue

            action_outputs = policy_net(expressions[i], first_token=first_token)
            if action_outputs is None:
                continue

            # 转成可微分的向量
            action_outputs = torch.tensor(
                [item['prob'] for item in action_outputs],
                dtype=torch.float32, device=device, requires_grad=True
            )

            loss = compute_policy_loss(action_outputs, target_policy, classification_loss_fn, device)
            policy_loss = policy_loss + loss

        if policy_loss.requires_grad:
            policy_loss.backward()
            optimizer.step()
            total_policy_loss += policy_loss.item()
            valid_samples += 1

    avg_policy_loss = total_policy_loss / valid_samples if valid_samples > 0 else 0.0
    return avg_policy_loss

#####################################
#        顺序批量训练 - value       #
#####################################
def train_value_net(value_net, optimizer, replay_buffer, num_batches, batch_size, device):
    """
    1. 顺序采样 batch_size 条数据（直到把缓冲区数据遍历完）。
    2. 对于每个样本，逐个传入表达式（字符串）进行前向传播，
       计算均方误差并累加 loss，再进行一次反向传播和参数更新。
    """
    value_net.train()
    regression_loss_fn = nn.MSELoss()
    total_value_loss = 0.0
    total_samples = 0

    num_data = len(replay_buffer)
    if num_data == 0:
        return 0.0

    for _ in range(num_batches):
        batch_data = replay_buffer.sample(batch_size)
        if not batch_data:
            continue

        # 拆分出 states、action_probs_list、values、expressions
        # 这里 states 不再使用，因为网络只依赖表达式
        expressions, _, values= zip(*batch_data)

        optimizer.zero_grad()
        batch_loss = 0.0

        # 对 batch 内每个样本逐个计算
        for i in range(len(batch_data)):
            target_value = values[i]  # 目标价值，通常为标量

            # 单个样本的前向传播
            output = value_net(expressions[i]).squeeze(-1)
            # 将目标值转换为 tensor
            target_tensor = torch.tensor(target_value, dtype=torch.float32, device=device).unsqueeze(0)
            # 计算均方误差损失
            sample_loss = regression_loss_fn(output, target_tensor)
            # 累加每个样本的损失
            batch_loss += sample_loss

        # 对整个 batch 的累加损失一次反向传播和参数更新
        batch_loss.backward()
        optimizer.step()

        total_value_loss += batch_loss.item()
        total_samples += len(batch_data)  # 直接用 batch_data 的实际样本数

    avg_value_loss = total_value_loss / total_samples if total_samples > 0 else 0.0
    return avg_value_loss



#####################################
#         自我对弈 & 并行相关       #
#####################################
def self_play_game(policy_net, value_net, LEN, MCTS_SIM, MCTS_PARALLEL, BATCH_SIZE_EVAL, device=torch.device('cpu')):
    """
    利用当前策略网络、价值网络和 MCTS 执行自我对弈，返回该局的所有步骤数据。
    """
    mcts = MCTS(policy_net, value_net, MCTS_SIM, MCTS_PARALLEL, BATCH_SIZE_EVAL, device)
    game_data = []  # (state_tensor, action_probs, current_expression, reached_terminal, final_state)

    length = 0

    while (not mcts.root.state.is_terminal_state()) and length <= (LEN - 1):
        current_expression = mcts.root.state.state_description()
        coef = 1
        final_probas, _ = mcts.search(competitive=False, c_puct=1, temperature=1)
        game_data.append((final_probas, current_expression,coef,False, mcts.root.state))
        length += 1

    # 若到达终止状态则把 reached_terminal 改为 True
    if mcts.root.state.is_terminal_state():
        for idx in range(len(game_data)):
            game_data[idx] = (
                game_data[idx][0],      # final_probas
                game_data[idx][1],      # current_expression
                game_data[idx][2],      # coef
                True,                   # reached_terminal 改成 True
                mcts.root.state         # final_state
            )

    return game_data

def run_self_play(args):
    (policy_net, value_net, LEN, MCTS_SIM, MCTS_PARALLEL, BATCH_SIZE_EVAL, device, seed) = args

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if device.type == 'cuda':
        torch.cuda.manual_seed_all(seed)

    return self_play_game(policy_net, value_net, LEN, MCTS_SIM, MCTS_PARALLEL, BATCH_SIZE_EVAL, device)

def init_pool(*args):
    pass

def parallel_self_play(policy_net, value_net, LEN, num_games, MCTS_SIM, MCTS_PARALLEL, BATCH_SIZE_EVAL, device, num_workers):
    seeds = [random.randint(0, 1e8) for _ in range(num_games)]
    args_list = [(policy_net, value_net, LEN, MCTS_SIM, MCTS_PARALLEL, BATCH_SIZE_EVAL, device, s) for s in seeds]

    mp.set_start_method('spawn', force=True)
    with mp.Pool(processes=num_workers, initializer=partial(init_pool, device)) as pool:
        results = pool.map(partial(run_self_play), args_list)
    return results


#####################################
#   process_game_data_and_calculate_rewards
#####################################
def process_game_data_and_calculate_rewards(all_game_data, replay_buffer, file, pool, logo=False):
    """
    收集自我对弈的 game_data，计算最终回报并存入 ReplayBuffer。
    """

    for game in all_game_data:
        final_ic = 0
        final_expression = None
        
        # 再寻找终止状态，更新 final_expression 和 final_ic
        for step in reversed(game):
            if step[-2]:  # reached_terminal=True
                final_expression = parse_expression_from_string(step[-1].state_description())
                try:
                    # 更新所有步骤的 coef
                    for idx in range(len(game)):
                        step = list(game[idx])
                        state_str = step[-4]
                        step[-3] = 1 - pool.compute_avg_similarity_with_pool(state_str)
                        game[idx] = tuple(step)
                            
                    pool.try_new_expr(final_expression)
                    final_ic = pool.evaluate_ensemble()
                    if final_ic < 0:
                        final_ic = 0
                    logger.info(f"{final_expression},{final_ic}")     
                except OutOfDataRangeError:
                    final_ic = 0
                break


        # 记录
        if final_expression is not None:
            # 接下来保存到缓冲区时，每个 step 的 coef 都是最新更新过的值
            for step_idx, step in enumerate(game):
                raw_pi, current_expression, coef, _, _ = step
                reward = final_ic if (step_idx == len(game) - 1) else final_ic*coef
                target_policy = mcts_policy_to_target(raw_pi)
                replay_buffer.push(current_expression,target_policy, reward)
                if logo:
                    with open(file, 'a', newline='', encoding='utf-8') as f:
                        writer = csv.writer(f)
                        writer.writerow([
                            target_policy,
                            reward,
                            current_expression,
                            final_expression,
                            coef
                        ])
        